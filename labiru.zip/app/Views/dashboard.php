<?= $this->extend('layouts\template') ?>

<?= $this->section('header') ?>
<title>Home</title>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<h1>Hello</h1>
<?= $this->endSection() ?>